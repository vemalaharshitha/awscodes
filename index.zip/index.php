<?php
if (isset($_POST['submit'])) {
    // Get input values from form
    $name = $_POST['name'];
    $m1 = $_POST['m1'];
    $m2 = $_POST['m2'];
    $m3 = $_POST['m3'];

    // Calculate total and average
    $total = $m1 + $m2 + $m3;
    $avg = $total / 3;

    // Determine grade
    if ($avg >= 90) {
        $grade = "A+";
    } elseif ($avg >= 80) {
        $grade = "A";
    } elseif ($avg >= 70) {
        $grade = "B";
    } elseif ($avg >= 60) {
        $grade = "C";
    } else {
        $grade = "Fail";
    }

    // Display result
    echo "<div style='background:#f4f4f4; padding:20px; border-radius:10px; width:400px; margin:auto; text-align:center;'>";
    echo "<h2>Student Result</h2>";
    echo "<p><strong>Name:</strong> $name</p>";
    echo "<p><strong>Total Marks:</strong> $total</p>";
    echo "<p><strong>Average:</strong> $avg</p>";
    echo "<p><strong>Grade:</strong> $grade</p>";
    echo "</div>";
} else {
?>
<!-- Input Form -->
<div style="text-align:center; margin-top:50px;">
    <h2>Student Result Calculator</h2>
    <form method="POST" style="display:inline-block; text-align:left; padding:20px; border:1px solid #ccc; border-radius:10px;">
        Name: <input type="text" name="name" required><br><br>
        Mark 1: <input type="number" name="m1" required><br><br>
        Mark 2: <input type="number" name="m2" required><br><br>
        Mark 3: <input type="number" name="m3" required><br><br>
        <button type="submit" name="submit">Calculate</button>
    </form>
</div>
<?php
}
?>
